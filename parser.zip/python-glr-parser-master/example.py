# -*- coding: utf-8 -*-
from glr import GLRParser

dictionaries = {
    u"CLOTHES": [u"который", u"думы"]
}

grammar = u"""
    S = noun
"""

glr = GLRParser(grammar, dictionaries=dictionaries, debug=False)

arr = []

text = u'''
Регламент Государственной Думы является нормативным актом, который регулирует порядок ее работы, внутреннее устройство и парламентские процедуры. Обязанности по контролю за соблюдением регламента, обобщению предложений по его изменению и разъяснению отдельных его положений возлагается на Комитет Государственной Думы по контролю и Регламентуs
Регламент Государственной Думы 

Принят постановлением Государственной Думы Федерального Собрания Российской Федерации 
от 22 января 1998 года № 2134-II ГД
'''
handle = open("output.txt", "w")
prev = 0
prevl = 0
for parsed in glr.parse(text):
    try:
        arr.append([text.index(parsed), parsed])
        prev = text.index(parsed)
        prevl = len(parsed)
    except:
        arr.append([prev+1+prevl, parsed])
    print "FOUND:", parsed

grammar = u"""
    S = verb
"""

glr = GLRParser(grammar, dictionaries=dictionaries, debug=False)
prev = 0
prevl = 0
for parsed in glr.parse(text):
    try:
        arr.append([text.index(parsed), parsed])
        prev = text.index(parsed)
        prevl = len(parsed)
    except:
        arr.append([prev+1+prevl, parsed])
    print "FOUND:", parsed
arr.sort()
for i in arr:
    handle.write(i[1].encode('utf-8')+" ")
handle.close()
	

